# Danish School: local Windows / VS Code setup and start.
# Run from an ordinary PowerShell terminal:
#   powershell -ExecutionPolicy Bypass -File .\START-WEBSITE-WINDOWS.ps1
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Assert-Exit([string]$Step) {
    if ($LASTEXITCODE -ne 0) { throw "$Step failed (exit code $LASTEXITCODE). See the output above." }
}

try {
    if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
        throw 'Node.js is missing. Install Node.js 22.13 or newer from https://nodejs.org/ and restart PowerShell.'
    }
    $nodeVersionString = (& node --version).TrimStart('v')
    $nodeVersion = [version]$nodeVersionString
    if ($nodeVersion -lt [version]'22.13.0') { throw "Node.js $nodeVersionString is too old. Install Node.js 22.13 or newer." }
    if (-not (Get-Command corepack -ErrorAction SilentlyContinue)) {
        throw 'Corepack is missing. Install/enable Corepack, or install pnpm version 11.25.0, then try again.'
    }

    $varsPath = Join-Path $PSScriptRoot '.dev.vars'
    if (-not (Test-Path $varsPath)) {
        $randomBytes = New-Object byte[] 32
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        try { $rng.GetBytes($randomBytes) } finally { $rng.Dispose() }
        $secret = [System.BitConverter]::ToString($randomBytes).Replace('-', '').ToLowerInvariant()
        [System.IO.File]::WriteAllText($varsPath, "ADMIN_KEY=$secret`r`n")
        Write-Host 'Generated a unique local admin password in .dev.vars (keep it private).' -ForegroundColor Green
        Write-Host 'To sign in at /admin, open .dev.vars locally and use the value after ADMIN_KEY=.'
    } else {
        Write-Host 'Using existing .dev.vars admin password.'
    }

    Write-Host '[1/4] Installing dependencies using the project lockfile ...' -ForegroundColor Cyan
    & corepack pnpm install --frozen-lockfile
    Assert-Exit 'Dependency installation'

    Write-Host '[2/4] Building frontend and backend ...' -ForegroundColor Cyan
    & corepack pnpm run build
    Assert-Exit 'Build'

    Write-Host '[3/4] Initializing the local SQL database ...' -ForegroundColor Cyan
    # Idempotent on subsequent runs. Matches drizzle/0000_cuddly_bastion.sql.
    $sql = 'CREATE TABLE IF NOT EXISTS records (id text PRIMARY KEY NOT NULL, collection text NOT NULL, payload text NOT NULL, created_at text NOT NULL);'
    & corepack pnpm exec wrangler d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --command $sql
    Assert-Exit 'Database setup'

    Write-Host '[4/4] Starting website ...' -ForegroundColor Green
    Write-Host 'Website: http://localhost:5173'
    Write-Host 'Admin:   http://localhost:5173/admin'
    Write-Host 'API:     http://localhost:5173/api/health'
    Write-Host 'Press Ctrl+C to stop the local server. Localhost is NOT a public internet URL.'
    & corepack pnpm run dev
    Assert-Exit 'Development server'
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
