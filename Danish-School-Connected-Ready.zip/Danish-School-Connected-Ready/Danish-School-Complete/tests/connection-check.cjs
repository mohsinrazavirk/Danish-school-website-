const fs = require('node:fs');
const assert = require('node:assert/strict');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const front = read('app/page.tsx');
const admin = read('app/admin/page.tsx');
const api = read('app/api/[...path]/route.ts');
const schema = read('db/schema.ts');
const migration = read('drizzle/0000_cuddly_bastion.sql');
const hosting = JSON.parse(read('.openai/hosting.json'));
assert.match(front, /fetch\('\/api\/'\+name/);
assert.match(front, /fetch\('\/api\/'\+kind/);
for (const endpoint of ['teachers', 'news', 'gallery', 'admissions', 'contacts', 'students']) {
  assert.ok(api.includes(`'${endpoint}'`), `Backend missing ${endpoint}`);
}
for (const route of ['login', 'logout']) assert.ok(api.includes(`'${route}'`), `Missing ${route} route`);
assert.ok(admin.includes("fetch('/api/'"), 'Admin must use local API');
assert.match(api, /env\.DB/);
assert.match(schema, /sqliteTable\("records"/);
assert.match(migration, /CREATE TABLE `records`/);
assert.equal(hosting.d1, 'DB');
for (const name of ['classroom', 'computer-lab', 'learning', 'library', 'science']) {
  assert.ok(fs.statSync(path.join(root, 'public', 'images', `${name}.webp`)).size > 0, `Missing ${name} photo`);
}
console.log('PASS: homepage ↔ API routes, admin ↔ API, D1 binding/schema/migration, and all five images');
