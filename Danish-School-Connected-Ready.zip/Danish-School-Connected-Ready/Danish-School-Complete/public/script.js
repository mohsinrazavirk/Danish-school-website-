const escapeHTML = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const API = "/api";


// ==========================================
// GET TEACHERS FROM BACKEND
// ==========================================

async function loadTeachers() {

    try {

        const response =
            await fetch(`${API}/teachers`);

        const data =
            await response.json();

        const teacherList =
            document.getElementById("teacherList");

        teacherList.innerHTML = "";

        data.teachers.forEach(teacher => {

            teacherList.innerHTML += `

                <div class="card">

                    <h3>
                        ${escapeHTML(teacher.name)}
                    </h3>

                    <p>
                        Subject:
                        ${escapeHTML(teacher.subject)}
                    </p>

                    <p>
                        Experience:
                        ${escapeHTML(teacher.experience)}
                    </p>

                </div>

            `;

        });

    } catch (error) {

        console.error(error);

        document.getElementById(
                "teacherList"
            ).innerHTML =
            "<p>Unable to load teachers.</p>";

    }

}


// ==========================================
// GET NEWS FROM BACKEND
// ==========================================

async function loadNews() {

    try {

        const response =
            await fetch(`${API}/news`);

        const data =
            await response.json();

        const newsList =
            document.getElementById("newsList");

        newsList.innerHTML = "";

        data.news.forEach(item => {

            newsList.innerHTML += `

                <article class="card">

                    <h3>
                        ${escapeHTML(item.title)}
                    </h3>

                    <p>
                        ${escapeHTML(item.description)}
                    </p>

                    <small>
                        ${escapeHTML(item.date)}
                    </small>

                </article>

            `;

        });

    } catch (error) {

        console.error(error);

        document.getElementById(
                "newsList"
            ).innerHTML =
            "<p>Unable to load news.</p>";

    }

}


// ==========================================
// ADMISSION FORM → BACKEND API
// ==========================================

document
    .getElementById("admissionForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();
 if(this.dataset.busy)return; this.dataset.busy="1"; this.querySelector("button").disabled=true;

        const formData =
            new FormData(this);

        const admissionData =
            Object.fromEntries(formData);

        try {

            const response =
                await fetch(
                    `${API}/admissions`, {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json"
                        },

                        body: JSON.stringify(
                            admissionData
                        )
                    }
                );

            const data =
                await response.json();

            document.getElementById(
                    "admissionMessage"
                ).textContent =
                data.message + (data.id ? " Reference: " + data.id : "");

            if (data.success) {

                this.reset();

            }

        } catch (error) {

            document.getElementById(
                    "admissionMessage"
                ).textContent =
                "Server error. Please try again.";

        } finally { delete this.dataset.busy; this.querySelector("button").disabled=false; }

    });


// ==========================================
// CONTACT FORM → BACKEND API
// ==========================================

document
    .getElementById("contactForm")
    .addEventListener("submit", async function(event) {

        event.preventDefault();
 if(this.dataset.busy)return; this.dataset.busy="1"; this.querySelector("button").disabled=true;

        const formData =
            new FormData(this);

        const contactData =
            Object.fromEntries(formData);

        try {

            const response =
                await fetch(
                    `${API}/contact`, {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json"
                        },

                        body: JSON.stringify(
                            contactData
                        )
                    }
                );

            const data =
                await response.json();

            document.getElementById(
                    "contactMessage"
                ).textContent =
                data.message + (data.id ? " Reference: " + data.id : "");

            if (data.success) {

                this.reset();

            }

        } catch (error) {

            document.getElementById(
                    "contactMessage"
                ).textContent =
                "Server error. Please try again.";

        } finally { delete this.dataset.busy; this.querySelector("button").disabled=false; }

    });


// ==========================================
// LOAD DATA WHEN PAGE OPENS
// ==========================================

loadTeachers();

loadNews();