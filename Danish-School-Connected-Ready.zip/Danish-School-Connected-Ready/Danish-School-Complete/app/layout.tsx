import "./globals.css";
export const metadata={title:"Danish School",description:"Explore Danish School programs, teachers and learning experiences. Apply for Grades 1–10 or contact the school."};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="en"><head><link rel="stylesheet" href="/style.css"/></head><body>{children}</body></html>}
