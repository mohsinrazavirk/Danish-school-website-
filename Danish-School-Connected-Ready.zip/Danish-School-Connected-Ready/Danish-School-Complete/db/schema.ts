import { sqliteTable, text } from "drizzle-orm/sqlite-core";
export const records = sqliteTable("records", { id: text("id").primaryKey(), collection: text("collection").notNull(), payload: text("payload").notNull(), createdAt: text("created_at").notNull() });
