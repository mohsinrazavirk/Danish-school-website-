# Danish School

The original school design is retained. The backend now uses a durable Cloudflare D1 SQL database instead of the broken JSON data file. Hosting provisions the database and applies the schema migration.

## Features
- Public teachers and news from the database.
- Validated admission applications and contact messages, with saved reference IDs.
- Password-protected /admin: manage students, teachers, news, admissions and contacts; export each collection as JSON.
- Existing source data: 2 students, 3 teachers, 3 news articles. Imported once on the first collection request. No existing admissions or messages were present in the upload.
- Server-side authorization, parameterized SQL, same-origin mutation checks and escaped frontend text.

## Administrator
Open /admin and enter the separately supplied admin password. ADMIN_KEY is configured as a hosting secret and is never committed to source. Sessions use HttpOnly, Secure and SameSite=Strict cookies. Use HTTPS. The deployed site is owner-private by default.

## Development
Use Node 22.13+ and pnpm. Run `pnpm install`, then `pnpm run build`. Apply drizzle/0000_cuddly_bastion.sql to local DB using the starter README instructions. Configure ADMIN_KEY in the local development environment to test admin sign-in, and run `pnpm run dev`.

Local preview and hosted databases are separate. Local QA records are not deployed. Persistent production data stays in D1 across deployments. Use the admin export buttons for downloadable JSON copies.

## Verification
Build passed. SQLite-backed API checks covered seed import, required field and email validation, admission/contact storage, unauthenticated access rejection, admin sign-in, create/update/delete, deletion persistence and DB health. Browser QA verified database-driven teachers/news and successful admission submission with a reference ID.

The original footer contact details are retained from the supplied project; verify them before inviting visitors. Admission applications and contact messages are stored only; sending email/SMS was not configured.

## Website update (21 October 2026)
- New responsive navy, cream and gold design with accessible navigation, academic program tabs, FAQs and clearer forms.
- Five optimized local WebP photographs from Pexels, explicitly labeled illustrative. Source URLs are retained in gallery records; these are not presented as actual school campus photographs.
- Added persistent gallery collection to the existing records table. `/api/gallery` supplies the photo grid and its category filters; administrator CRUD is available in the Gallery tab. The one-time gallery seed has its own marker and does not replace existing school records.
- Gallery image URLs must be HTTPS or local `/images/` paths; source links must be HTTPS. Gallery categories are Learning, Science, Technology and Library.
- Public content APIs: `GET /api/teachers`, `GET /api/news`, `GET /api/gallery`. Form APIs: `POST /api/admissions`, `POST /api/contact`. API reference: `GET /api/openapi` (OpenAPI JSON).
- API-backed content shows loading states and retry controls. Forms prevent duplicate simultaneous submissions and display saved reference IDs.
- Run `node tests/api.cjs` for SQLite-backed API checks, including gallery validation and deletion persistence. Run `node node_modules/typescript/bin/tsc --noEmit --incremental false` for type checks.
- Existing admin password and database are retained. No external payment, WhatsApp or email delivery API is configured.
