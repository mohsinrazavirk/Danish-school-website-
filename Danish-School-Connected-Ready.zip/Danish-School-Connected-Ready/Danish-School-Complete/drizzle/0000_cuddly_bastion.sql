CREATE TABLE `records` (
	`id` text PRIMARY KEY NOT NULL,
	`collection` text NOT NULL,
	`payload` text NOT NULL,
	`created_at` text NOT NULL
);
