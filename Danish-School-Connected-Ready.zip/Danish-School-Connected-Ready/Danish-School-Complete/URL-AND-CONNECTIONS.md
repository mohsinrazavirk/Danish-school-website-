# Danish School — URL, Frontend, Backend, Database

## Which link can be shared?

The **previously documented website URL**, recorded in the uploaded project's `START-HERE.txt`, is:

https://danish-school-mohsin.creamrain17.chatgpt.site

**Important:** This is the existing site's address, not a new deployment. This extracted source archive does **not** prove the live site is publicly accessible or matches the latest local files. The uploaded `SCHOOL-SETUP.md` says the hosted project was **owner-private by default**. In ChatGPT Sites, open the existing Danish School project, choose **Share**, select **Anyone on the internet** if permitted, and **Publish**. Use **Visit** / **Copy link** to confirm its current URL. Test from a signed-out/incognito browser. Republishing or importing modified files must be done through the Sites project; editing a downloaded ZIP never automatically updates the live website.

A browser can open a direct URL even when the site is not indexed by Google's search results. Showing in Google Search requires separate indexing steps and is not guaranteed.

## What is actually connected in this source?

| Website component | File | Backend endpoint | SQL storage |
|---|---|---|---|
| Teachers displayed on homepage | `app/page.tsx` | `GET /api/teachers` | D1 `records` (collection `teachers`) |
| News displayed on homepage | `app/page.tsx` | `GET /api/news` | D1 `records` (collection `news`) |
| Gallery displayed on homepage | `app/page.tsx` | `GET /api/gallery` | D1 `records` (collection `gallery`) |
| Admission form | `app/page.tsx` | `POST /api/admissions` | D1 `records` (collection `admissions`) |
| Contact form | `app/page.tsx` | `POST /api/contact` | D1 `records` (collection `contacts`) |
| Admin login and record management | `app/admin/page.tsx` | `/api/login`, `/api/students`, etc. | D1 `records` |
| Database connectivity check | `app/api/[...path]/route.ts` | `GET /api/health` | D1 |

Frontend API calls use **relative same-origin addresses** (`/api/...`), so they work on both `localhost` and a correctly deployed website without any external API URL. The React frontend is in `app/page.tsx`; `public/script.js` is a *legacy unused script* and is not the active frontend for the current website.

`db/schema.ts`, `drizzle/0000_cuddly_bastion.sql`, `.openai/hosting.json`, and Cloudflare D1 binding `DB` supply the database schema and connection. The database must be provisioned and migrated on the chosen host. Live production and local D1 records are **not shared**.

## Run it on a Windows 64-bit laptop

1. Install Node.js **22.13+** and open this extracted folder in VS Code.
2. In VS Code, open **Terminal → New Terminal**, then run:

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\START-WEBSITE-WINDOWS.ps1
   ```

3. The startup script installs project dependencies, builds the app, creates a local `.dev.vars` administrator secret (only if it does not already exist), initializes the local D1 SQL table, and starts the app.
4. Visit **http://localhost:5173** for the site, **http://localhost:5173/admin** for the admin panel, and **http://localhost:5173/api/health** for the backend/database check.
5. For the admin password, privately open `.dev.vars` in VS Code and copy the `ADMIN_KEY` value. **Never upload `.dev.vars` or share this secret with visitors.**

The app's packages must be downloaded over the internet on first install. If there are dependency or Windows PowerShell restrictions, follow `README.md` / `SCHOOL-SETUP.md` for manual commands.

## Testing and deployment

- `node tests/api.cjs`: local SQL-backed API functionality tests after installing dependencies.
- `node tests/connection-check.cjs`: checks the expected wiring and supplied files.
- `GET /api/health` should return a JSON result with `success: true` when D1 is reachable.
- Submit a **test** admission/contact form and confirm it appears under `/admin` — **only on a test deployment** to avoid storing fake production student data.
- For the already hosted ChatGPT Site, edit/re-publish in Sites rather than assuming the ZIP has automatically updated the hosted version. Live production data is **not included** in the ZIP.

Do not publish sample school contact details as verified: review the email, location, gallery descriptions, and consent/privacy notice before making the site public. This code **saves** admission and contact records; it does **not** automatically send email, WhatsApp, or SMS notifications.
